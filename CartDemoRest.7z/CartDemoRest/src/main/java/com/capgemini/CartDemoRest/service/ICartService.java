package com.capgemini.CartDemoRest.service;

import java.util.List;


import com.capgemini.CartDemoRest.model.Customer;
import com.capgemini.CartDemoRest.model.Inventory;
import com.capgemini.CartDemoRest.model.ManagingCart;

public interface ICartService {

	 public List<ManagingCart> getAll(int proId);

	public void save(ManagingCart managingCart);

	public void deleteProduct(Integer cartId);

	public void update(ManagingCart cart);

	public Customer findCust(Integer custId);

	public Inventory getInventory(Integer proId);

	//public void addToCart(ManagingCart cart);

	//public void save(ManagingCart managingCart);

}
