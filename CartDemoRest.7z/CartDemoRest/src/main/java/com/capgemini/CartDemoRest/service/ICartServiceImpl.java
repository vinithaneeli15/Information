package com.capgemini.CartDemoRest.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.CartDemoRest.dao.ICartDao;
import com.capgemini.CartDemoRest.dao.ICustomerDao;
import com.capgemini.CartDemoRest.dao.IInventoryDao;
import com.capgemini.CartDemoRest.model.Customer;
import com.capgemini.CartDemoRest.model.Inventory;
import com.capgemini.CartDemoRest.model.ManagingCart;

@Service("cartService")
public class ICartServiceImpl implements ICartService {
	
	@Autowired
	private ICartDao cartDao;
	@Autowired
	private ICustomerDao customerDao;
	@Autowired
	private IInventoryDao inventoryDao;
	@Override
	public List<ManagingCart> getAll(int proId) {
		
		/*return  (List<ManagingCart>) cartDao.findProduct(proId);*/
		return  cartDao.findProduct(proId);
	}
/*
	@Override
	public void addToCart(ManagingCart cart) {
		
		cartDao.save(cart);
		
	}
*/
	/*@Override
	public void save(ManagingCart managingCart) {
		// cartDao.create(managingCart);
		cartDao.save(managingCart);
		
	}*/

	@Override
	public void save(ManagingCart managingCart) {
		cartDao.save(managingCart);
		
	}

	@Override
	public void deleteProduct(Integer cartId) {
		cartDao.deleteById(cartId);
		
	}

	@Override
	public void update(ManagingCart cart) {
		
		cartDao.save(cart);
			
			
		
		
	}

	@Override
	public Customer findCust(Integer custId) {
		
		return customerDao.getOne(custId);
	}

	@Override
	public Inventory getInventory(Integer proId) {
		// TODO Auto-generated method stub
		return inventoryDao.getOne(proId);
	}

	
   
	
	
	
}
