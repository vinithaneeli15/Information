package com.capgemini.CartDemoRest.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.CartDemoRest.model.Inventory;
import com.capgemini.CartDemoRest.model.ManagingCart;
@Repository("inventoryDao")
@Transactional
public interface IInventoryDao  extends JpaRepository<Inventory, Integer>{

}
