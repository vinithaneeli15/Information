package com.capgemini.CartDemoRest.controller;

import java.util.List;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.CartDemoRest.model.Customer;
import com.capgemini.CartDemoRest.model.Inventory;
import com.capgemini.CartDemoRest.model.ManagingCart;
import com.capgemini.CartDemoRest.service.ICartService;


@RestController
@RequestMapping("/api/v1")
public class CartController {
	
	@Autowired
	 private ICartService cartService;
	
	
	@GetMapping("/products/{custId}")
	public ResponseEntity<List<ManagingCart>> getCart(@PathVariable("custId") Integer custId) {
		
		List<ManagingCart> managingCart = cartService.getAll(custId);
		
		//System.out.println("Products:" + wishList);
		if(managingCart == null || managingCart.isEmpty()) {
			return new ResponseEntity("Cart is not available", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<ManagingCart>>(managingCart, HttpStatus.OK);
	}
	
	
	
	@PostMapping("/addToCart/{proId}")
	public ResponseEntity<ManagingCart> createCart(@RequestBody ManagingCart managingCart,@PathVariable("proId") Integer proId) {
		Inventory inventory=cartService.getInventory(proId);
		managingCart.setInventory(inventory);
		managingCart.setStatus("Not Confirmed");
		managingCart.setQuantity(1);
		Customer customer=cartService.findCust(1);
		managingCart.setCustomers(customer);
		cartService.save(managingCart);
		return new ResponseEntity<ManagingCart>(HttpStatus.OK);
	}
	
	
	@DeleteMapping("/products/{cartId}")
	public void deleteCart(@PathVariable("cartId") Integer cartId) {
		cartService.deleteProduct(cartId);
	}
	
	@PutMapping("/products")
	public void updateQty(@RequestBody ManagingCart cart) {
		cartService.update(cart);
	}
	/*@PostMapping("/buyNow/{custId}")
	public ResponseEntity<ManagingCart> buyNow(@RequestBody ManagingCart managingCart,@PathVariable("custId") Integer custId) {
		managingCart.setStatus("Bought Directly");
		managingCart.setQuantity(1);
		Customer customer=cartService.findCust(custId);
		managingCart.setCustomers(customer);
		cartService.save(managingCart);
		return new ResponseEntity<ManagingCart>(HttpStatus.OK);
	}*/
	
	
	
}
