package com.capgemini.CartDemoRest.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
public class Inventory {
	
	@Id
	@GeneratedValue
	@Column(name="product_id")
	private int productId;
	
	private String productName;
	
	private double price;
	
	@OneToMany(targetEntity=ManagingCart.class,mappedBy="inventory")
	private List<ManagingCart> managingCart;

	
	
	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public Inventory(int productId, String productName, double price, List<ManagingCart> managingCart) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.managingCart = managingCart;
	}


	public Inventory() {
		
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}

  
	/*public List<ManagingCart> getWishList() {
		return managingCart;
	}*/


	public void setWishList(List<ManagingCart> managingCart) {
		this.managingCart = managingCart;
	}
	
	
}
