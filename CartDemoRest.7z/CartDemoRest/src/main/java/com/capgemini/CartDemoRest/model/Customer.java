package com.capgemini.CartDemoRest.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
public class Customer {
	@Id
	@GeneratedValue
	@Column(name="cust_id")
	private int custId;
	
	private String custName;
	

	@OneToMany(targetEntity=ManagingCart.class,mappedBy="customers")
	private List<ManagingCart> managingCart;

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	/*public List<ManagingCart> getWishList() {
		return managingCart;
	}*/

	public void setWishList(List<ManagingCart> wishList) {
		this.managingCart = wishList;
	}

	public Customer(int custId, String custName, List<ManagingCart> managingCart) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.managingCart = managingCart;
	}
	public Customer() {
		
	}
	
	
	
}
