package hotelBooking;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.BookingPageBean;
import pages.LogInPageBean;


public class StepDef {
	private WebDriver driver;
    private LogInPageBean logInPageBean;
    private BookingPageBean bookingPageBean;
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		logInPageBean= new LogInPageBean(driver);
		bookingPageBean= new BookingPageBean(driver);
		
	}
	
	@Given("^login form is open$")
	public void login_form_is_open() throws Throwable {
	    driver.get("D:\\sts-bundle\\BDD\\153044_HotelBookingApp\\src\\main\\webapp\\login.html");
	    String pageHeading=logInPageBean.getHeading();
	    assertTrue(pageHeading.equals("Hotel Booking Application"));
	}

	@When("^I blindly click on next$")
	public void i_blindly_click_on_next() throws Throwable {
		logInPageBean.setBtn();
	}

	@Then("^alert message for User Name will be raised$")
	public void alert_message_for_User_Name_will_be_raised() throws Throwable {
		Thread.sleep(500);
	}

	@When("^I enter the User Name and press next$")
	public void i_enter_the_User_Name_and_press_next() throws Throwable {
		
		logInPageBean.setUserName("capgemini");
		logInPageBean.setBtn();
	}

	@Then("^Alert message for password will be raised$")
	public void alert_message_for_password_will_be_raised() throws Throwable {
		
    	Thread.sleep(500);
	}

	@When("^I enter the password and press next$")
	public void i_enter_the_password_and_press_next() throws Throwable {
		logInPageBean.setPassword("capg1234");
		logInPageBean.setBtn();
	}

	@Then("^navigate to hotel booking form$")
	public void navigate_to_hotel_booking_form() throws Throwable {
		driver.navigate().refresh();
	}

	@When("^I blindly click on confirm booking$")
	public void i_blindly_click_on_confirm_booking() throws Throwable {
		bookingPageBean.setBtn2();
	}
	  
	
	@Then("^Alert message for first name will be raised$")
	public void alert_message_for_first_name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name");
	}

	@When("^I enter the first name and click confirm booking$")
	public void i_enter_the_first_name_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for last name will be raised$")
	public void alert_message_for_last_name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
    	Thread.sleep(500);
	}

	@When("^I enter the last Name and  click confirm booking$")
	public void i_enter_the_last_Name_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for email will be raised$")
	public void alert_message_for_email_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
    	Thread.sleep(500);
	}

	@When("^I enter the invalid email and click confirm booking$")
	public void i_enter_the_invalid_email_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmailcom");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for enter valid email id will be raised$")
	public void alert_message_for_enter_valid_email_id_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
    	Thread.sleep(500);
	}

	@When("^I enter the valid email and click confirm booking$")
	public void i_enter_the_valid_email_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for enter mobileno will be raised$")
	public void alert_message_for_enter_mobileno_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Mobile No.");
    	Thread.sleep(500);
	}

	@When("^I enter the invalid mobileno  and click confirm booking$")
	public void i_enter_the_invalid_mobileno_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("12345");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for enter valid mobileno will be raised$")
	public void alert_message_for_enter_valid_mobileno_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
    	Thread.sleep(500);
	}

	@When("^I enter the valid mobileno only and click confirm booking$")
	public void i_enter_the_valid_mobileno_only_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setBtn2(); 
		
	}

	

	@Then("^Alert message for enter city will be raised$")
	public void alert_message_for_enter_city_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select city");
    	Thread.sleep(500);
	}
	@When("^I enter the city and click confirm booking$")
	public void i_enter_the_city_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setBtn2(); 
		
	}

	@Then("^Alert message for enter state will be raised$")
	public void alert_message_for_enter_state_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select state");
    	Thread.sleep(500);
	}

	@When("^I enter the state and click confirm booking$")
	public void i_enter_the_state_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setState("Tamilnadu");
		bookingPageBean.setBtn2(); 
	}

	

	@Then("^Alert message for card holder name will be raised$")
	public void alert_message_for_card_holder_name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
    	Thread.sleep(500);
	}

	@When("^I enter card holder name and click confirm booking$")
	public void i_enter_card_holder_name_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setState("Tamilnadu");
		bookingPageBean.setNoOfGuest("2");
		bookingPageBean.setCardHolderName("Vinitha Neeli");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for card number name will be raised$")
	public void alert_message_for_card_number_name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
    	Thread.sleep(500);
	}

	@When("^I enter card number and click confirm booking$")
	public void i_enter_card_number_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setState("Tamilnadu");
		bookingPageBean.setNoOfGuest("2");
		bookingPageBean.setCardHolderName("Vinitha Neeli");
		bookingPageBean.setDbCardNumber("1234561234561234");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for cvv will be raised$")
	public void alert_message_for_cvv_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the CVV");
    	Thread.sleep(500);
	}

	

	@When("^I enter valid cvv and click confirm booking$")
	public void i_enter_valid_cvv_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setState("Tamilnadu");
		bookingPageBean.setNoOfGuest("2");
		bookingPageBean.setCardHolderName("Vinitha Neeli");
		bookingPageBean.setDbCardNumber("1234561234561234");
		bookingPageBean.setCvv("123");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for expiration month will be raised$")
	public void alert_message_for_expiration_month_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
    	Thread.sleep(500);
	}


	@When("^I enter valid expiration month and click confirm booking$")
	public void i_enter_valid_expiration_month_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setState("Tamilnadu");
		bookingPageBean.setNoOfGuest("2");
		bookingPageBean.setCardHolderName("Vinitha Neeli");
		bookingPageBean.setDbCardNumber("1234561234561234");
		bookingPageBean.setCvv("123");
		bookingPageBean.setExpiryMonth("11");
		bookingPageBean.setBtn2(); 
	}

	@Then("^Alert message for expiration year will be raised$")
	public void alert_message_for_expiration_year_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the expiration year");
    	Thread.sleep(500);
	}


	@When("^I enter the expiration year and press click confirm booking$")
	public void i_enter_the_expiration_year_and_press_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		bookingPageBean.setFirstName("Vinitha");
		bookingPageBean.setLastName("Neeli");
		bookingPageBean.setEmail("abc@gmail.com");
		bookingPageBean.setPhone("7894561230");
		bookingPageBean.setAddress("MW City");
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setState("Tamilnadu");
		bookingPageBean.setNoOfGuest("2");
		bookingPageBean.setCardHolderName("Vinitha Neeli");
		bookingPageBean.setDbCardNumber("1234561234561234");
		bookingPageBean.setCvv("123");
		bookingPageBean.setExpiryMonth("11");
		bookingPageBean.setExpiryYear("2025");
		bookingPageBean.setBtn2(); 
	}
	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		
		driver.navigate().refresh();
		Thread.sleep(500);
	}

	@After
	public void tearDown() {
		driver.close();
	}

}
