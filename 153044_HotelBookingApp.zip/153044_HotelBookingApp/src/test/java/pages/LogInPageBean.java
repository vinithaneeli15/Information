package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LogInPageBean {
	 WebDriver driver;
		
		@FindBy(name="userName")
		private WebElement userName;
		
		@FindBy(name="userPwd")
		private WebElement password;
		
		@FindBy(how=How.XPATH,using="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
		private WebElement btn;
		
		@FindBy(how=How.XPATH,using="//*[@id=\"mainCnt\"]/div/div[1]/h1")
		private WebElement heading;
		
		
		public LogInPageBean(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
		public String getHeading() {
			return heading.getText();
		}
		public void setUserName(String usrName) {
			this.userName.sendKeys(usrName); 
		}

		public void setPassword(String pwd) {
			this.password.sendKeys(pwd);
		}
		public void setBtn() {
			this.btn.click();
		}
		
		

}
