package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class HotelDetails {
	
	@Id
	private int id;
	private String name;
	private String rate;
	private double rateNumber;
	private int availableRooms;
	public HotelDetails() {
		super();
	}
	public HotelDetails(int id, String name, String rate, double rateNumber, int availableRooms) {
		super();
		this.id = id;
		this.name = name;
		this.rate = rate;
		this.rateNumber = rateNumber;
		this.availableRooms = availableRooms;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public double getRateNumber() {
		return rateNumber;
	}
	public void setRateNumber(double rateNumber) {
		this.rateNumber = rateNumber;
	}
	public int getAvailableRooms() {
		return availableRooms;
	}
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	@Override
	public String toString() {
		return "HotelDetails [id=" + id + ", name=" + name + ", rate=" + rate + ", rateNumber=" + rateNumber
				+ ", availableRooms=" + availableRooms + "]";
	}
	
	

}
