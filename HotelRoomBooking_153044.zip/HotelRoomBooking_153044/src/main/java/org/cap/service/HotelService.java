package org.cap.service;

import java.util.List;

import org.cap.model.HotelDetails;
/**
 * Interface  : HotelService
 * @author    : Vinitha Neeli
 * Date       : 28th July,2018 
 * purpose    : To get data from  service implementation
 * No of methods : 1
 *
 */
public interface HotelService {
	/**
	 * method name  :getAllDetails
	 * parameters   :nil
	 * Return type  : list of hotel details 
	 * purpose      : get all the data from service implementation
	 * Author       : Vinitha Neeli
	 * Date of creation:28th July,2018 
	 * Last Modified Date : 28th July,2018 
	 */

	 public List<HotelDetails> getAllDetails();

}
