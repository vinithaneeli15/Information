package org.cap.service;

import java.util.List;

import org.cap.dao.HotelDao;
import org.cap.model.HotelDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * class   : HotelServiceImpl
 * @author : Vinitha Neeli
 * Date    : 28th July,2018 
 * purpose : To get data from  associated data store
 * No of methods : 1
 *
 */
@Service("hotelService")
public class HotelServiceImpl implements HotelService {
	
	@Autowired
	private HotelDao hotelDao;
	/**
	 * method name  :getAllDetails
	 * parameters   :nil
	 * Return type  : list of hotel details 
	 * purpose      : get all the data from dao interface
	 * Author       : Vinitha Neeli
	 * Date of creation:28th July,2018 
	 * Last Modified Date : 28th July,2018 
	 */

	@Override
	public List<HotelDetails> getAllDetails() {
		
		return hotelDao.getAllDetails();
	}

}
