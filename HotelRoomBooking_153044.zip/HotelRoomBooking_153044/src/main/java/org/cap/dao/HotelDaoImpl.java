package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.cap.model.HotelDetails;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


/**
 * class   : HotelDaoImpl
 * @author : Vinitha Neeli
 * Date    : 28th July,2018 
 * purpose : To get data from  associated data store
 * No of methods : 1
 *
 */

@Repository("hotelDao")
@Transactional
public class HotelDaoImpl implements HotelDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	
	/**
	 * method name  :getAllDetails
	 * parameters   :nil
	 * Return type  : list of hotel details 
	 * purpose      : Retrieves all the data from underlying Data store
	 * Author       : Vinitha Neeli
	 * Date of creation:28th July,2018 
	 * Last Modified Date : 28th July,2018 
	 */
	@Override
	@Transactional(readOnly=true)
	public List<HotelDetails> getAllDetails() {
	
			List<HotelDetails> hotelInfo=entityManager.createQuery("from HotelDetails").getResultList();
				
			return hotelInfo;
		}
	}

