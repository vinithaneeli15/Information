package org.cap.dao;

import java.util.List;

import org.cap.model.HotelDetails;
/**
 * Interface  : HotelDao
 * @author    : Vinitha Neeli
 * Date       : 28th July,2018 
 * purpose    : To get data from  associated data store
 * No of methods : 1
 *
 */
public interface HotelDao {
	/**
	 * method name  :getAllDetails
	 * parameters   :nil
	 * Return type  : list of hotel details 
	 * purpose      : get all the data from dao implementation
	 * Author       : Vinitha Neeli
	 * Date of creation:28th July,2018 
	 * Last Modified Date : 28th July,2018 
	 */

	 public List<HotelDetails> getAllDetails();

}
