package org.cap.controller;

import java.util.List;

import org.cap.model.HotelDetails;

import org.cap.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;
/**
 * class     : HotelController
 * @author    : Vinitha Neeli
 * Date       : 28th July,2018 
 * No of methods : 3
 *
 */
@Controller
public class HotelController {
	
	@Autowired
	 private HotelService hotelService;
	String hotelName;
	/**
	 * method name  :getHotelDetails
	 * parameters   :nil
	 * Return type  : string which returns jsp page name 
	 * purpose      : get all the data from service layer
	 * Author       : Vinitha Neeli
	 * Date of creation:28th July,2018 
	 * Last Modified Date : 28th July,2018 
	 */
	
	 @RequestMapping("/")
     public String getHotelDetails(ModelMap map) {
    	 
    	List<HotelDetails> details=hotelService.getAllDetails();
    	
    	map.put("hoteldetails",details);
    	
    	
		return "hotelDetails";
    
    	 
     }
	 /**
		 * method name  :hotelBooking
		 * parameters   :nil
		 * Return type  : string which returns jsp page name 
		 * purpose      : to book the hotel
		 * Author       : Vinitha Neeli
		 * Date of creation:28th July,2018 
		 * Last Modified Date : 28th July,2018 
		 */
	 @RequestMapping("/hotelbooking/{name}")
	 public String hotelBooking(@PathVariable("name") String name) {
		 hotelName=name;
		return "hotelBooking";
		 
	 }
	 /**
		 * method name  :hotelBooking
		 * parameters   :nil
		 * Return type  : model and view object 
		 * purpose      : to display the confirmation message
		 * Author       : Vinitha Neeli
		 * Date of creation:28th July,2018 
		 * Last Modified Date : 28th July,2018 
		 */
	 @RequestMapping("/hotelbooking/bookingSuccess")
	 public ModelAndView bookingsuccess() {
		
		return new ModelAndView("hotelBookingSuccess","hotelName",hotelName);
		 
	 }
	 
    
}
