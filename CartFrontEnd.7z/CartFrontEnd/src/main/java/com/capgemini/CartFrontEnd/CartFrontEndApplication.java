package com.capgemini.CartFrontEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartFrontEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartFrontEndApplication.class, args);
	}
}
